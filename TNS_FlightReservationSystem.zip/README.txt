
Este proyecto depende de la base de datos PostgreSQL

Para crear la base de datos 'flight_reservation_system':
Una vez instalado PostgreSQL, abrir la consola 
de postgres y copiar y pegar todo el contenido de 
los documentos en este orden:

	1. ScryptDBFlightReservationSystem
	2. Triggers_Procedures
	3. Poblamiento2

Abrir el proyecto en netbeans, abrir en 'src/Model'
la clase conexion, y modificar las variables user y pw
con el usuario y la contrase�a que le hayas puesto a la
base de datos.

Ejecutar el proyecto en netbeans.